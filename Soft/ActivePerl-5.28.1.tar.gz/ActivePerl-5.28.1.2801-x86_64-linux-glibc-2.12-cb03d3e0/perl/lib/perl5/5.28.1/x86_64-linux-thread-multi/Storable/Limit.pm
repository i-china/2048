# bisected by stacksize
$Storable::recursion_limit = 12554
  unless defined $Storable::recursion_limit;
$Storable::recursion_limit_hash = 7526
  unless defined $Storable::recursion_limit_hash;
1;
