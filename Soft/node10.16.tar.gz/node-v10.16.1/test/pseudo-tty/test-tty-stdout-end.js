'use strict';
require('../common');

process.stdout.end();
