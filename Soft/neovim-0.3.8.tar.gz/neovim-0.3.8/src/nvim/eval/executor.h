#ifndef NVIM_EVAL_EXECUTOR_H
#define NVIM_EVAL_EXECUTOR_H

#include "nvim/eval/typval.h"

extern char *e_listidx;

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "eval/executor.h.generated.h"
#endif
#endif  // NVIM_EVAL_EXECUTOR_H
