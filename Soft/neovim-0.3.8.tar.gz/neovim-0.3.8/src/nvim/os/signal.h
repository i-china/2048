#ifndef NVIM_OS_SIGNAL_H
#define NVIM_OS_SIGNAL_H

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "os/signal.h.generated.h"
#endif
#endif  // NVIM_OS_SIGNAL_H
