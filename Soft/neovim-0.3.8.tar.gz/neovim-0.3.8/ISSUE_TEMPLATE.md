<!-- Before reporting: search existing issues and check the FAQ. -->

- `nvim --version`:
- Vim (version: ) behaves differently?
- Operating system/version:
- Terminal name/version:
- `$TERM`:

### Steps to reproduce using `nvim -u NORC`

```
nvim -u NORC

```

### Actual behaviour

### Expected behaviour

